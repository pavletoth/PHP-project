<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>L'Express</title>
</head>
<body>
    <?php
        include 'connect.php';
        define('UPLPATH', 'slike/');
        session_start();
        if($_SESSION['user'] !== "yes"){
            header("Location: login.php");
        }
    ?>
</head>
<body>
    <header>
        <img src="slike/logo.png" alt="L'Express logo" width="50%">

    <nav>
          <ul>
            <li>
                <a href="index.php">HOME</a>
            </li>
            <li>
                <a href="kategorija.php?type=svijet">SVIJET</a>
            </li>
            <li>
                <a href="kategorija.php?type=ekonomija">EKONOMIJA</a>
            </li>
            <?php
                    if($_SESSION['admin'] == 1){
                        echo '<a href="unos.php" class="link-style"><p>Input news</p></a>';
                        echo '<a href="administracija.php" class="link-style"><p>Administration</p></a>';
                    }
                    ?>
            <li>
                <a href="logout.php" id="odjava">Odjavi se</a>
            </li>
        </ul>
    </nav>
    </header>
<container>
<section>
        <?php
            $id = $_GET['id'];
            $query = "SELECT id, datum, naslov, sazetak, tekst, slika FROM vijesti WHERE id='{$id}'";
            $result = mysqli_query($dbc, $query);
            while($row = mysqli_fetch_array($result)){
                echo '<img src="' . UPLPATH . $row['slika'] . '" id="slika"';
                echo "<br>";
                echo "<h2>";
                    echo $row['naslov'];
                echo "</h2>";
                echo "<p class='date'>";
                    echo $row['datum'];
                echo "</p>";
                echo "<article>";
                    echo $row['sazetak'];
                echo "</article>";
                echo "<br>";
                echo "<article>";
                    echo $row['tekst'];
                echo "</article>";
            }
        ?>
</section>
</container>
    <footer>
        Sva prava zadržava L'Express.
        Za više informacija javite se na naš <a href="mailto:ptoth@tvz.hr">mail.</a>
    </footer>
</body>
</html>