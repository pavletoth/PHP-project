<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>L'Express</title>
</head>
<body>
<header>
    <img src="slike/logo.png" alt="L'Express logo" width="50%">
<nav>
      <ul>
        <li>
            HOME
        </li>
        <li>
            SVIJET
        </li>
        <li>
            EKONOMIJA
        </li>
        <li>
            ADMINISTRACIJA
        </li>
        <li>
            LOKALNE PONUDE
        </li>
      </ul>
</nav>
</header>
<main>
        <?php
        $title = $_GET['title'] ?? '';
        $about = $_GET['about'] ?? '';
        $content = $_GET['content'] ?? '';
        $photo = $_GET['photo'] ?? '';
        $today = $_GET['today'] ?? '';
        define('UPLPATH', 'slike/');
        
        echo '<img src="' . UPLPATH . "{$photo}". '">';
        echo "<h2>{$title}</h2>";
        echo "<p class='date'>{$today}</p>";
        echo "<article>{$about}</article>";
        echo "<article>{$content}</article>";
        ?>
    </main>
    <footer>
    Sva prava zadržava L'Express.
    Za više informacija javite se na naš <a href="mailto:ptoth@tvz.hr">mail.</a>
</footer>
</body>
</html>