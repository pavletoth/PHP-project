<?php
    $dbc = mysqli_connect('localhost', 'root', '', 'vijesti', 8080) or die ('Greška u povezivanju s bazom podataka.');
?>