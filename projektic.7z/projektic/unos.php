<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>L'Express</title>
</head>
<body>
<header>
    <img src="slike/logo.png" alt="L'Express logo" width="50%">
<nav>
      <ul>
        <li>
            HOME
        </li>
        <li>
            SVIJET
        </li>
        <li>
            EKONOMIJA
        </li>
        <li>
            ADMINISTRACIJA
        </li>
        <li>
            LOKALNE PONUDE
        </li>
      </ul>
</nav>
</header>   
<body>
        <form name="newsForm" method="POST" action="insert.php">
            <div class="form-item">
                <label for="title">Naslov vijesti</label>
                <input type="text" name="title" class="field-text">
            </div>  
            <div class="form-item">
                <label for="about">Kratki sadržaj vijesti (do 50 znakova):</label>
                <div class="form-field">
                    <textarea name="about" cols="15" rows="5" class="field-text"></textarea>
                </div>

            </div>
            <div class="form-item">
                <label for="content">Sadržaj vijesti: </label>
                <div class="form-field">
                    <textarea name="content" cols="30" rows="10" class="field-text"></textarea>
                </div>
            </div>
            <div class="form-item-button">
                <label for="photo">Slika: </label>
                <div class="form-field">
                    <input type="file" name="photo" class="form-button" accept="slike/jpg, slike/jpeg, slike/png">
                </div>
            </div>
            <div class="form-item">
                <label for="category">Kategorija vijesti:</label>
                <div class="form-field">
                    <select name="category" class="form-item">
                        <option value="svijet">Svijet</option>
                        <option value="ekonomija">Ekonomija</option>
                    </select>
                </div>
            </div>
            <div class="form-item-button">
                <label for="save">Spremiti u arhivu?</label>
                <div class="form-field">
                    <input type="checkbox" name="save">
                </div>
            </div>
            <div class="form-item-button">
                <button type="reset" value="Poništi">Poništi</button>
                <button type="submit" value="Prihvati" name="submit">Prihvati</button>
            </div>
        </form>
    <footer>
        Sva prava zadržava L'Express.
        Za više informacija javite se na naš <a href="mailto:ptoth@tvz.hr">mail.</a>
    </footer>
</body>
</html>