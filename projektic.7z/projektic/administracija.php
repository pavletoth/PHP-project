<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>L'Express</title>

    <style>
        .error-message {
            color: red;
            font-size: 0.9em;
        }
    </style>
    <?php
        include 'connect.php';
        define('UPLPATH', 'slike/');
        session_start();
        if($_SESSION['user'] !== "yes"){
            header("Location: login.php");
        }
    ?>
    <script>
        function validateForm() {
            var labels = document.querySelectorAll('form[name="newsForm"] label');
            labels.forEach(function(label) {
                label.classList.remove('error-message');
                label.textContent = label.textContent.replace(/:.*/, ':');
            });

            var isValid = true;

            var title = document.forms["newsForm"]["title"];
            var about = document.forms["newsForm"]["about"];
            var content = document.forms["newsForm"]["content"];
            var photo = document.forms["newsForm"]["photo"];
            var category = document.forms["newsForm"]["category"];

            if (title.value.length < 5 || title.value.length > 50) {
                showError(title, "Unesi do 50 znakova.");
                isValid = false;
            }

            if (about.value.length < 10 || about.value.length > 100) {
                showError(about, "Mora sadržavati od 10 do 100 znakova.");
                isValid = false;
            }

            if (content.value == "") {
                showError(content, "Unesi neki tekst");
                isValid = false;
            }

            if (photo.value == "") {
                showError(photo, "Slika nije odabrana");
                isValid = false;
            }

            if (category.value == "") {
                showError(category, "Kategorija nije označena");
                isValid = false;
            }

            return isValid;
        }

        function showError(element, message) {
            var label = document.querySelector('label[for="' + element.name + '"]');
            label.classList.add('error-message');
            label.textContent += " " + message;
            element.style.border = "1px dotted red";
        }
    </script>
</head>
<body>
<header>
        <img src="slike/logo.png" alt="L'Express logo" width="50%">

    <nav>
        <ul>
            <li>
                <a href="index.php">HOME</a>
            </li>
            <li>
                <a href="kategorija.php?type=svijet">SVIJET</a>
            </li>
            <li>
                <a href="kategorija.php?type=ekonomija">EKONOMIJA</a>
            </li>
            <?php
                    if($_SESSION['admin'] == 1){
                        echo '<a href="unos.php" ><p>Unesi vijest</p></a>';
                        echo '<a href="administracija.php"><p>Administracija</p></a>';
                    }
                    ?>
            <li>
                <a href="logout.php" id="odjava">Odjavi se</a>
            </li>
        </ul>
    </nav>
    </header>
<main>
<?php
        if(isset($_GET['id'])){
            $id = $_GET['id'] ?? '';
            $news_query = "SELECT * FROM vijesti WHERE id=$id";
            $result2 = mysqli_query($dbc, $news_query);
            while($row = mysqli_fetch_array($result2)){
                echo "</table>";
                echo "<form name='newsForm' method='POST' enctype='multipart/form-data' onsubmit='return validateForm()' action='administracija.php?id=$id'>";
                    echo '<div >';
                        echo '<label for="title">Naslov</label>';
                        echo '<input type="text" name="title"  value="' . $row['naslov'] . '">';
                    echo '</div>';
                    echo '<div >';
                        echo '<label for="about">Kratki sadrzaj vijesti(do 50 znakova):</label>';
                        echo '<textarea name="about" cols="15" rows="5" >' . $row['sazetak'] . '</textarea>';
                    echo '</div>';
                    echo '<div >';
                        echo '<label for="content">Sadržaj vijesti:</label>';
                        echo '<textarea name="content" cols="30" rows="10" >' . $row['tekst'] . '</textarea>';
                    echo '</div>';
                    echo '<div >';
                        echo '<div >';
                            echo '<input type="file"  name="photo"/> ';
                            echo '<img src="' . UPLPATH . $row['slika'] . '" width=100px>';
                        echo '</div>';
                    echo '</div>';
                    echo '<div >';
                        echo '<label for="category">Kategorija</label>';
                        echo '<select name="category" >';
                            echo '<option value="crude"' . ($row['kategorija'] == 'svijet' ? ' selected' : '') . '>Svijet</option>';
                            echo '<option value="gas"' . ($row['kategorija'] == 'ekonomija' ? ' selected' : '') . '>Ekonomija</option>';
                        echo '</select>';
                    echo '</div>';
                    echo '<div >';
                        echo '<label for="save">Spremiti u arhivu?</label>';
                        echo '<input type="checkbox" name="save" value="1"' . ($row['arhiva'] ? ' checked' : '') . '>';
                    echo '</div>';
                    echo '<div >';
                        echo '<button type="reset" value="Reset">Poništi</button>';
                        echo '<button type="submit" name="delete">Obrisi</button>';
                        echo '<button type="submit" name="submit">Prihvati</button>';
                    echo '</div>';
                echo '</form>';
            }
            if(isset($_POST['submit'])) {
                $title = mysqli_real_escape_string($dbc, $_POST['title']);
                $about = mysqli_real_escape_string($dbc, $_POST['about']);
                $content = mysqli_real_escape_string($dbc, $_POST['content']);
                $category = mysqli_real_escape_string($dbc, $_POST['category']);
                $save = isset($_POST['save']) ? 1 : 0;
                $photo = $row['slika'];
                if (!empty($_FILES['photo']['name'])) {
                    $photo = $_FILES['photo']['name'];
                    move_uploaded_file($_FILES['photo']['tmp_name'], UPLPATH . $photo);
                }
                $update_query = "UPDATE vijesti SET 
                    naslov='$title',
                    sazetak='$about',
                    tekst='$content',
                    slika='$photo',
                    kategorija='$category',
                    arhiva='$save'
                    WHERE id=$id";
                $result = mysqli_query($dbc, $update_query);
                if($result){
                    header('Location: administracija.php');
                }
            }
            if(isset($_POST['delete'])){
                $delete_query = "DELETE FROM vijesti WHERE id=$id";
                $result = mysqli_query($dbc, $delete_query);
                if($result){
                    header('Location: administracija.php');
                }
            }
        }
    ?>
    <table>
        <tr>
            <td>id</td>
            <td>date</td>
            <td>title</td>
            <td>image</td>
            <td>category</td>
            <td>archive</td>
        </tr>
    <?php
        $query = "SELECT * FROM vijesti";
        $result = mysqli_query($dbc, $query);
        while($row = mysqli_fetch_array($result)){ 
            $id = $row['id']; 
            echo "<tr>";
                echo "<td><a href='administracija.php?id=$id'>";
                echo $row['id'];
                echo "</a></td>";
                echo "<td>";                       
                    echo $row['datum'];                        
                echo "</td>";
                echo "<td><a href='administracija.php?id=$id'>";
                    echo $row['naslov'];
                echo "</a></td>";
                echo "<td>";
                    echo $row['slika'];
                echo "</td>";
                echo "<td>";
                    echo $row['kategorija'];
                echo "</td>";
                echo "<td>";
                    echo $row['arhiva'];
                echo "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</main>
    <footer>
    Sva prava zadržava L'Express.
    Za više informacija javite se na naš <a href="mailto:ptoth@tvz.hr">mail.</a>
    </footer>
</body>
</html>can y